import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-shared',
  templateUrl: './update-shared.component.html',
  styleUrls: ['./update-shared.component.scss']
})
export class UpdateSharedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
