import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reponce',
  templateUrl: './reponce.component.html',
  styleUrls: ['./reponce.component.scss']
})
export class ReponceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
