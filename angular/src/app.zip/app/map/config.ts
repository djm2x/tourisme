export const KEY2 = 'AIzaSyBS5VM_9o7FKZYe2kzmxQ_s5sxxtCzCm8c';
export const KEY3 = 'AIzaSyDm1sMO4dR7OrZWe5Ten0_Ol2p7QXdsjwo';
export const KEY = '';
